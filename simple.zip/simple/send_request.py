#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
 send_request.py - the smallest possible BSSV SOAP tester
===============================================================================

 Reads ONE url from url.csv, POSTs request.xml to it, and prints EVERYTHING
 that went out and came back. Built for one job: working out why a request
 that succeeds in SoapUI fails from a script.

 Three files, nothing else:
     send_request.py   this program
     request.xml       the SOAP payload
     url.csv           the endpoint (a header row + one URL)

 No config file. No dependencies - Python 3.6+ standard library only, so it
 runs on a locked-down server with no pip install.

 RUN IT
     python send_request.py

 OPTIONS (all optional)
     python send_request.py --url https://host/PD920OR/Service   ignore url.csv
     python send_request.py --xml other.xml                      another payload
     python send_request.py --csv other.csv                      another list
     python send_request.py --all                 send to EVERY url in the csv
     python send_request.py --timeout 60          default 30 seconds
     python send_request.py --verify              turn TLS checking ON
     python send_request.py --soap-action urn:x   default is ""
     python send_request.py --quiet               summary only, no bodies

 EXIT CODES
     0  HTTP 200 and no SOAP Fault
     1  HTTP 200 but the body carried a SOAP Fault
     2  a non-200 answer
     3  could not connect / timeout / TLS failure
     4  a file was missing or unreadable
===============================================================================
"""

import argparse
import csv
import os
import ssl
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
LINE = "=" * 78

# Anything still containing these was never filled in with real credentials.
PLACEHOLDERS = ("DUMMY_USER", "DUMMY_PASSWORD", "CHANGEME", "YOUR_USER", "YOUR_PASSWORD")


def read_urls(path):
    """First column of a CSV, header row skipped. Blank/# lines ignored."""
    if not os.path.isfile(path):
        print(f"[!] URL file not found: {path}")
        sys.exit(4)

    urls = []
    with open(path, "r", newline="", encoding="utf-8-sig") as handle:
        for row in csv.reader(handle):
            if not row:
                continue
            value = (row[0] or "").strip()
            if not value or value.startswith("#"):
                continue
            if value.lower() in ("url", "endpoint", "endpointurl"):
                continue  # the header
            urls.append(value)
    if not urls:
        print(f"[!] No URL found in {path}")
        sys.exit(4)
    return urls


def load_payload(path):
    """Return the payload bytes, warning about anything that causes a 500."""
    if not os.path.isfile(path):
        print(f"[!] Payload not found: {path}")
        sys.exit(4)

    with open(path, "rb") as handle:
        raw = handle.read()

    notes = []
    if raw[:3] == b"\xef\xbb\xbf":
        notes.append(
            "UTF-8 BOM at the start of the file. BSSV answers HTTP 500 to this, "
            "and the file looks perfectly normal in an editor. Re-save it as "
            "'UTF-8 without BOM'  (Notepad++: Encoding > Convert to UTF-8)."
        )
    elif raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        notes.append("File is UTF-16. Re-save it as UTF-8 without BOM.")
    elif raw[:1].isspace():
        notes.append(
            "The file starts with whitespace/a blank line before the XML. "
            "Some SOAP stacks reject that with HTTP 500 - delete it."
        )

    text = raw.decode("utf-8", errors="replace")
    for placeholder in PLACEHOLDERS:
        if placeholder in text:
            notes.append(
                f"The payload still contains the placeholder '{placeholder}'. "
                "The server will reject it - usually HTTP 500 with a security "
                "fault - while SoapUI works because it has real credentials."
            )
            break

    return raw, notes


def find_fault(body):
    """Pull the faultstring out of a SOAP Fault, if there is one."""
    import re

    if not re.search(r"<\s*(?:[\w.-]+:)?Fault[\s>]", body, re.IGNORECASE):
        return None
    match = re.search(
        r"<\s*(?:[\w.-]+:)?(?:faultstring|message|Text)[^>]*>(.*?)<\s*/",
        body, re.IGNORECASE | re.DOTALL,
    )
    return " ".join(match.group(1).split()) if match else "(fault with no faultstring)"


def send(url, payload, args, notes):
    print(LINE)
    print("REQUEST")
    print(LINE)
    print(f"POST {url}")

    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": args.soap_action,
        "Accept": "text/xml, application/soap+xml, */*",
        "User-Agent": "BSSV-Simple/1.0",
        "Content-Length": str(len(payload)),
    }
    print("\nHeaders sent:")
    for key, value in headers.items():
        print(f"    {key}: {value}")

    print(f"\nPayload: {args.xml}  ({len(payload)} bytes)")
    for note in notes:
        print(f"    [!] {note}")

    if not args.quiet:
        print("\n--- payload as sent ---")
        print(payload.decode("utf-8", errors="replace"))

    context = None
    if url.lower().startswith("https"):
        if args.verify:
            context = ssl.create_default_context()
        else:
            context = ssl._create_unverified_context()
            print("\n[i] TLS certificate checking is OFF (pass --verify to turn it on)")

    request = urllib.request.Request(url, data=payload, headers=headers, method="POST")

    started = time.time()
    status, reason, body, resp_headers = None, "", "", []

    try:
        with urllib.request.urlopen(request, timeout=args.timeout, context=context) as response:
            status = response.status
            reason = response.reason
            resp_headers = response.getheaders()
            body = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        # A 500 still has a body, and for BSSV that body is the actual answer.
        status = exc.code
        reason = exc.reason
        resp_headers = list(exc.headers.items()) if exc.headers else []
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
    except urllib.error.URLError as exc:
        elapsed = int((time.time() - started) * 1000)
        print(f"\n{LINE}\nRESPONSE\n{LINE}")
        print(f"NO RESPONSE after {elapsed} ms")
        print(f"    {exc.reason}")
        print("\nThat is a network/TLS problem, not a SOAP one:")
        print("    * firewall between this host and the BSSV port")
        print("    * wrong host or port in the URL")
        print("    * TLS handshake refused (try without --verify)")
        print(f"    Test the port with:  Test-NetConnection <host> -Port <port>")
        return 3
    except Exception as exc:  # noqa: BLE001
        print(f"\n[!] {type(exc).__name__}: {exc}")
        return 3

    elapsed = int((time.time() - started) * 1000)

    print(f"\n{LINE}")
    print("RESPONSE")
    print(LINE)
    print(f"HTTP {status} {reason}   ({elapsed} ms, {len(body)} bytes)")
    print("\nHeaders received:")
    for key, value in resp_headers:
        print(f"    {key}: {value}")

    if not args.quiet:
        print("\n--- body ---")
        print(body if body.strip() else "(empty)")

    saved = os.path.join(
        HERE, "response_{}.xml".format(datetime.now().strftime("%Y%m%d_%H%M%S"))
    )
    try:
        with open(saved, "w", encoding="utf-8") as handle:
            handle.write(body)
        print(f"\nResponse saved to: {saved}")
    except OSError as exc:
        print(f"\n[!] Could not save the response: {exc}")

    # ---- verdict -----------------------------------------------------------
    print(f"\n{LINE}")
    fault = find_fault(body)

    if status == 200 and not fault:
        print("RESULT: SUCCESS - HTTP 200, no SOAP Fault")
        print(LINE)
        return 0

    if status == 200 and fault:
        print("RESULT: SOAP FAULT (the server answered, but refused the request)")
        print(f"    {fault}")
        print("\n    Usually: wrong credentials, a locked/expired E1 user, or the")
        print("    service is not deployed in this environment.")
        print(LINE)
        return 1

    print(f"RESULT: HTTP {status}")
    if fault:
        print(f"    Fault: {fault}")
    print()
    if status == 500:
        print("    A BSSV 500 nearly always means the request reached the server")
        print("    and it disliked something. In order of likelihood:")
        print("      1. credentials in request.xml are wrong/placeholder/expired")
        print("      2. the XML has a BOM or leading whitespace (see the warnings above)")
        print("      3. the SOAPAction header is wrong - BSSV wants \"\" (two quotes)")
        print("      4. the payload is malformed, or is for a different operation")
        print("    The response body above is the server's own explanation - read it.")
    elif status == 404:
        print("    Wrong path. Check the environment code (DV920, PD920OR, PY920)")
        print("    and the service name in the URL.")
    elif status in (401, 403):
        print("    Rejected before SOAP was reached - a proxy, WebLogic auth, or")
        print("    a web server rule. Compare with what SoapUI sends.")
    print(LINE)
    return 2


def main():
    parser = argparse.ArgumentParser(
        description="POST an XML payload to a BSSV endpoint and show everything.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--csv", default=os.path.join(HERE, "url.csv"))
    parser.add_argument("--xml", default=os.path.join(HERE, "request.xml"))
    parser.add_argument("--url", default="", help="use this URL instead of the CSV")
    parser.add_argument("--all", action="store_true", help="send to every URL in the CSV")
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--verify", action="store_true", help="turn TLS checking ON")
    parser.add_argument("--soap-action", default='""')
    parser.add_argument("--quiet", action="store_true", help="summary only")
    args = parser.parse_args()

    args.xml = os.path.abspath(args.xml)
    args.csv = os.path.abspath(args.csv)

    payload, notes = load_payload(args.xml)

    if args.url:
        urls = [args.url]
    else:
        urls = read_urls(args.csv)
        if not args.all:
            if len(urls) > 1:
                print(f"[i] {len(urls)} URLs in {os.path.basename(args.csv)};")
                print("    sending to the first only. Pass --all to send to every one.\n")
            urls = urls[:1]

    worst = 0
    for index, url in enumerate(urls):
        if index:
            print("\n")
        code = send(url, payload, args, notes)
        worst = max(worst, code)
    return worst


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
