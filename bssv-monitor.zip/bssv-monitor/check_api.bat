@echo off
REM Validates the configuration the API would use, then exits. Nothing served.
setlocal
cd /d "%~dp0"
python bssv_api.py --once-check
pause
