#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate servers.csv - the endpoint metadata table read by bssv_monitor.py.

One row per endpoint URL. Rows join to a line in a check folder's BSSV_URL.txt
by the EndpointURL column, and supply what that endpoint is called, which
environment it belongs to, and the ExpectedText values to look for.

    python tools\\make_servers_csv.py             # writes ..\\servers.csv
    python tools\\make_servers_csv.py D:\\x.csv    # writes to a chosen path
    python tools\\make_servers_csv.py --force     # overwrite an existing file

An existing file is NOT overwritten unless --force is passed, so you cannot
lose your server list by accident.

The header row is what the program matches on; column order does not matter.
"""
import csv
import os
import sys

HEADERS = [
    ("Enabled",        "Y = this URL is checked, N = skipped."),
    ("CheckName",      "Optional. The check folder this URL belongs to, for readability. "
                       "Only used to warn you if it disagrees with where the URL actually is."),
    ("ServerName",     "Friendly name shown on the dashboard and in alerts. Defaults to the "
                       "hostname if left blank."),
    ("Environment",    "REQUIRED (here or in check.ini). PROD / PRE-PROD / UAT / TEST / DEV / "
                       "DR / TRAINING, or any code of your own. Drives the dashboard selector, "
                       "the alert subject and per-environment routing."),
    ("EndpointURL",    "REQUIRED. Must match a line in some check folder's BSSV_URL.txt - that "
                       "is how this row is joined to a request.xml."),
    ("ExpectedText",   "Values the response MUST contain, ';' separated - ALL must be present. "
                       "e.g. 081000;getAddressBookResponse. Blank = fall back to check.ini."),
    ("TimeoutSeconds", "Optional. Overrides check.ini and [request] timeout_seconds."),
    ("VerifySSL",      "Optional Y/N. Overrides check.ini and [request] verify_ssl."),
    ("AlertEmailTo",   "Optional. Overrides the recipients for this URL. QUOTE the cell if it "
                       "holds more than one address."),
    ("Notes",          "Free text - ignored by the program."),
]

SAMPLE_ROWS = [
    ["Y", "AddressBook", "BSSV-INT", "INT",
     "https://bssv-int-host.example.com/IN920OR/RI_AddressBookManager",
     "getAddressBookResponse", "45", "N", "", "Integration environment"],
    ["Y", "AddressBook", "BSSV-PROD", "PROD",
     "https://bssv-pd-host.example.com/PD920OR/RI_AddressBookManager",
     "081000;getAddressBookResponse", "45", "N", "jde-support@yourcompany.com",
     "Production - also asserts the 081000 value is returned"],
]


def build(path: str) -> None:
    # newline="" keeps csv from doubling line endings on Windows; utf-8-sig so
    # Excel opens it with the right encoding if someone double-clicks it.
    with open(path, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle, quoting=csv.QUOTE_ALL)
        writer.writerow([name for name, _note in HEADERS])
        writer.writerows(SAMPLE_ROWS)

    print(f"Written: {path}\n")
    print("Columns:")
    width = max(len(name) for name, _ in HEADERS)
    for name, note in HEADERS:
        print(f"  {name.ljust(width)}  {note}")
    print()
    print("Editing notes:")
    print("  * EndpointURL must match a line in a check folder's BSSV_URL.txt.")
    print("  * Environment is REQUIRED here or in that check's check.ini.")
    print("  * ExpectedText takes several values separated by ';' - ALL must appear")
    print("    in the response, e.g. 081000;getAddressBookResponse.")
    print('  * QUOTE any cell containing a comma: "ops@x.com,oncall@x.com".')
    print("  * In Excel use Save As -> CSV UTF-8 so it stays a CSV.")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--force"]
    force = "--force" in sys.argv
    default = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "servers.csv")
    target = args[0] if args else default
    if os.path.exists(target) and not force:
        sys.exit(f"Refusing to overwrite existing file: {target}\nPass --force if you really mean it.")
    build(target)
