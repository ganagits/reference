# BSSV Monitor

Scheduled connectivity + health monitoring for Oracle JD Edwards **Business
Services (BSSV)** endpoints.

A Python program POSTs a SOAP payload to each configured BSSV server, decides
whether the response is healthy, writes every result to a rolling CSV,
republishes a 72-hour JSON feed, and — **only when a check fails** — sends an
e-mail alert through a PowerShell `Send-MailMessage` script (no stored
password). A static, self-refreshing dashboard hosted in IIS or XAMPP shows the
last 72 hours.

```
   checks\<Name>\BSSV_URL.txt   the endpoints          ─┐
   checks\<Name>\request.xml    what gets POSTed        │
   checks\<Name>\check.ini      per-check settings      ├─► bssv_monitor.py
   servers.csv                  per-URL metadata        │        │
   config.ini                   everything else        ─┘        │
                                                                 ├─► logs\bssv_monitor_log.csv (72h)
                                                                 ├─► <web_root>\status.json ─► dashboard
                                                                 └─ on failure ─► send_alert.ps1 ─► Send-MailMessage
```

---

## 1. What counts as success

A check is **SUCCESS** only when all three hold:

1. HTTP status is **200**, **and**
2. the response body contains **no SOAP Fault**, **and**
3. every value in `ExpectedText` appears in the response — several values are
   allowed, separated by `;`, and **all** of them must be present.

Everything else is **FAILED** and is recorded with a machine-readable reason:

| `failure_reason` | Meaning |
|---|---|
| `HTTP_STATUS` | Server answered with a non-200 code (401, 404, 500 …) |
| `SOAP_FAULT` | HTTP 200 but the body carries a `soap:Fault` — bad credentials, E1 error, service not deployed |
| `EXPECTED_TEXT_MISSING` | Answered 200 with no fault, but one or more `ExpectedText` values were absent — the alert names which |
| `CONNECT_TIMEOUT` | TCP connect did not complete in time |
| `READ_TIMEOUT` | Connected, but no response within the timeout |
| `CONNECTION_ERROR` | Refused / host unreachable / DNS failure |
| `SSL_ERROR` | Certificate or TLS handshake problem |
| `PAYLOAD_UNREADABLE` | The check folder's `request.xml` is missing or locked |
| `UNEXPECTED_ERROR` | Anything else — full detail in `logs\bssv_monitor.log` |

Successes are logged and charted; they are **never** e-mailed.

---

## 2. Folder layout

```
bssv-monitor\
├─ bssv_monitor.py           the monitor
├─ config.ini                every tunable setting
├─ servers.csv               per-URL metadata (CSV, with a header row)
├─ send_alert.ps1            PowerShell mailer (Send-MailMessage, no password)
├─ requirements.txt          Python dependencies
├─ run_once.bat              single pass  - for Windows Task Scheduler
├─ run_loop.bat              resident loop - for a console window or NSSM
├─ checks\                   ONE FOLDER PER CHECK - auto-scanned
│   └─ AddressBook\
│       ├─ BSSV_URL.txt      the endpoint URLs, one per line
│       ├─ request.xml       the SOAP payload sent to every one of them
│       ├─ responds.xml      reference sample (not compared against)
│       └─ check.ini         optional per-check settings
├─ dashboard\
│   └─ index.html            published to web_root on every pass
├─ tools\
│   └─ make_servers_csv.py   regenerates a fresh servers.csv
└─ logs\
    ├─ bssv_monitor_log.csv  rolling 72h result log (auto-purged)
    ├─ bssv_monitor.log      application log (rotating)
    ├─ alert_state.json      alert throttle state
    ├─ archive\              purged rows, one CSV per month
    └─ responses\            raw bodies of failed responses
```

---

## 3. Install

Windows Server / Windows 10+ with Python 3.8 or newer.

```bat
cd C:\BSSV\bssv-monitor
python -m pip install -r requirements.txt
```

Dependencies: **`requests`** and `urllib3`. Nothing else — no database, no web
framework, no scheduler service.

`openpyxl` is **not** required. The server list is a CSV; openpyxl is imported
only if you point `server_list` at an `.xlsx` workbook (§5.2), and only then
does it need installing.

If the machine has no internet access, download the two wheels on a connected
machine and `pip install <wheel>` them locally.

---

## 4. A check folder

Everything needed to probe one BSSV service lives in one folder under
`checks\`. **Adding a service means dropping in a folder — nothing else to
register.**

```
checks\AddressBook\
├─ BSSV_URL.txt     REQUIRED - the endpoints
├─ request.xml      REQUIRED - the SOAP payload
├─ responds.xml     optional  - a recorded good response
└─ check.ini        optional  - per-check settings
```

### BSSV_URL.txt

One endpoint URL per line. `#` or `;` starts a comment; blank lines are
ignored. **The same `request.xml` is POSTed to every URL in the file**, so this
is normally the same service across environments:

```
# RI_AddressBookManager
https://bssv-int-host.example.com/IN920OR/RI_AddressBookManager
https://bssv-pd-host.example.com/PD920OR/RI_AddressBookManager
```

### request.xml

The SOAP envelope, exactly as SoapUI sends it — the shipped sample is the
`getAddressBook` request with a `wsse:UsernameToken` header:

```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:orac="http://oracle.e1.bssv.JPR01000/">
  <soapenv:Header>
    <wsse:Security ... soapenv:mustUnderstand="1">
      <wsse:UsernameToken>
        <wsse:Username>DUMMY_USER</wsse:Username>
        <wsse:Password Type="...#PasswordText">DUMMY_PASSWORD</wsse:Password>
      </wsse:UsernameToken>
    </wsse:Security>
  </soapenv:Header>
  <soapenv:Body>
    <orac:getAddressBook><entity><entityId>1</entityId></entity></orac:getAddressBook>
  </soapenv:Body>
</soapenv:Envelope>
```

**Credentials are hardcoded in this file**, which means every URL in
`BSSV_URL.txt` is hit with the same account. If INT and PROD need different
credentials, make two check folders. Practical consequences:

* Use a **dedicated, low-privilege monitoring E1 user** with a non-expiring
  password — a probe every 5 minutes will lock out an account whose password
  expires.
* Restrict NTFS permissions on `checks\` to the account the monitor runs as.
* `getAddressBook` for `entityId 1` is a good probe: read-only, always exists,
  cheap. **Never** point a check at `addAddressBook` or any other write.

### responds.xml

A recorded good response. **It is never compared against at run time** — the
pass/fail decision comes from the `ExpectedText` values in `servers.csv`.

It earns its place doing one thing: at startup, every `ExpectedText` value is
looked for in `responds.xml`, and you get a warning if it is not there:

```
WARNING  Check 'AddressBook': ExpectedText '081000' does not appear in
         responds.xml - a healthy server would be reported as FAILED.
         Check for a typo.
```

That catches a mistyped expected value at the moment you make it, instead of at
2am when it pages someone about a perfectly healthy server. Delete the file if
you do not want the check.

### check.ini

Every key optional; anything missing falls back to `config.ini`, and a
`servers.csv` row for a specific URL beats what is here.

```ini
[check]
enabled = true                              ; false = stop probing this folder
service_name = RI_AddressBookManager        ; defaults to the folder name
environment =                               ; fallback env for URLs with no CSV row
expected_text = getAddressBookResponse      ; used when the CSV row leaves it blank
timeout_seconds = 45
verify_ssl =
soap_action =
alert_email_to =
notes = getAddressBook for entityId 1
```

---

## 5. `servers.csv` — the per-URL metadata table

The check folder says **what to send**. This file says **what each endpoint
is** — its name, its environment, and the values that must come back.

**How the two join:** a row matches a line in some check folder's
`BSSV_URL.txt` by the `EndpointURL` column. That is the whole mechanism.

| Column | Required | Meaning |
|---|---|---|
| `Enabled` | no | `Y` = check this URL, `N` = skip it. Default `Y` |
| `CheckName` | no | Which check folder this URL belongs to. Only needed when two folders list the **same** URL and each needs its own row |
| `ServerName` | no | Name shown on the dashboard and in alerts. Defaults to the hostname (with the port, if non-standard) |
| `Environment` | **yes*** | `PROD` / `UAT` / `DEV` / … See §5.1. *Required here **or** as `environment=` in that check's `check.ini` |
| `EndpointURL` | **yes** | Must match a line in a `BSSV_URL.txt` — this is the join key |
| `ExpectedText` | no | Values the response must contain, `;` separated, **all** required. e.g. `081000;getAddressBookResponse` |
| `TimeoutSeconds` | no | Overrides `check.ini` and `[request] timeout_seconds` |
| `VerifySSL` | no | `Y`/`N`, overrides `check.ini` and `[request] verify_ssl` |
| `AlertEmailTo` | no | Overrides the recipients for this URL. **Quote the cell** if it holds more than one address |
| `Notes` | no | Free text — ignored |

The shipped file:

```csv
"Enabled","CheckName","ServerName","Environment","EndpointURL","ExpectedText","TimeoutSeconds","VerifySSL","AlertEmailTo","Notes"
"Y","AddressBook","BSSV-INT","INT","https://bssv-int-host.example.com/IN920OR/RI_AddressBookManager","getAddressBookResponse","45","N","","Integration environment"
"Y","AddressBook","BSSV-PROD","PROD","https://bssv-pd-host.example.com/PD920OR/RI_AddressBookManager","081000;getAddressBookResponse","45","N","jde-support@yourcompany.com","Production"
```

Both rows point at the same `request.xml` — they are the two lines of
`checks\AddressBook\BSSV_URL.txt`. The PROD row additionally asserts that
`081000` comes back, so it fails if E1 answers but returns the wrong data.

### Precedence

For every setting, highest first:

```
servers.csv row   ->   check.ini   ->   config.ini
```

Recipients have one extra step: the `AlertEmailTo` cell → `alert_email_to` in
`check.ini` → the `[email.recipients]` entry for that environment →
`[email] to_addresses`.

### What the program tells you about mistakes

Config errors are surfaced as warnings on every pass rather than failing
silently:

| Warning | Meaning |
|---|---|
| `servers.csv row N (…) matches no URL in any BSSV_URL.txt` | Dead row — the URL was renamed or removed from the check folder |
| `<Check> -> <url> skipped - no Environment` | The URL has no row here and no `environment=` in `check.ini` |
| `Check 'X' skipped - no request.xml` / `no BSSV_URL.txt` | Incomplete check folder |
| `ExpectedText 'v' does not appear in responds.xml` | Almost certainly a typo — see §4 |
| `servers.csv row N duplicates row M` | Same `CheckName` + `EndpointURL` twice; the first wins |

### A URL with no row

It still runs. The environment comes from `check.ini`, the name from the
hostname, and everything else from the defaults. A URL with no environment
*anywhere* is skipped with a warning — that is the one hard requirement.

### Editing notes

* **Quote any cell containing a comma** — several addresses in `AlertEmailTo`
  must be `"ops@x.com,oncall@x.com"` or the row splits into extra columns.
* `ExpectedText` uses `;` precisely because `,` is the CSV separator.
* If you edit in Excel, use **Save As → CSV UTF-8** so it stays a CSV.

To start from a fresh template:

```bat
python tools\make_servers_csv.py --force
```

### 5.1 Environment is a first-class dimension

`Environment` is **required** (in the CSV row or in `check.ini`) and is
upper-cased, so `prod`, `Prod` and `PROD` are one environment. It then flows
through everything:

| Where | What the environment does |
|---|---|
| CSV log | `environment` column on every row |
| **Dashboard** | An environment selector across the top. Picking one rescopes the whole page — counters, chart, server grid and history. Cards are grouped under environment headings; `PROD` is tinted red |
| **Alert subject** | Leads with the environment: `[BSSV ALERT] PROD - 2 BSSV check(s) FAILED - …` |
| **Alert body** | Failures grouped under an environment banner, production flagged |
| **Alert routing** | `[email.recipients]` sends each environment to its own distribution list |
| Ordering | Production sorts first everywhere |

Treated as production for the red tint: `PROD`, `PRODUCTION`, `PRD`, `LIVE`.
Sort order: PROD → PRE-PROD → DR → UAT → TEST → QA → DEV → TRAINING, then
anything unknown, alphabetically.

### 5.2 Using an Excel workbook instead

Point `server_list` at an `.xlsx` with the same column headers; the extension
picks the reader. This is the only path that needs `pip install openpyxl` —
the CSV default does not.

---

## 6. `config.ini`

Grouped by section. Paths may be absolute or relative to the folder holding
`config.ini`.

### `[general]`

| Key | Default | Meaning |
|---|---|---|
| `run_interval_seconds` | `300` | **Frequency.** Seconds between passes in loop mode |
| `run_mode` | `loop` | `loop` = stay resident; `once` = single pass and exit |
| `skip_missed_ticks` | `true` | If a pass overruns the interval, skip the missed tick instead of running back-to-back |
| `checks_dir` | `checks` | **Root holding one folder per check.** Scanned every pass, so a new folder is picked up without a restart |
| `server_list` | `servers.csv` | **The per-URL metadata table.** `.csv` (default, no extra dependency) or `.xlsx` (needs `openpyxl`). `excel_config` is accepted as an alias |
| `excel_sheet` | `Servers` | Sheet name — only used when `server_list` points at an `.xlsx` |

| `max_workers` | `4` | Servers probed in parallel; `1` = strictly sequential |

### `[request]`

| Key | Default | Meaning |
|---|---|---|
| `timeout_seconds` | `30` | Per-request timeout |
| `retries` | `1` | Extra attempts after the first failure. A check is FAILED only after all attempts fail — this suppresses alerts from single dropped packets |
| `retry_delay_seconds` | `5` | Pause between attempts |
| `verify_ssl` | `false` | TLS certificate verification |
| `ca_bundle` | *(blank)* | PEM file for your internal CA; used when `verify_ssl = true` |
| `default_soap_action` | `""` | SOAPAction header used unless a `check.ini` overrides it |
| `content_type` | `text/xml; charset=utf-8` | SOAP 1.1 content type |
| `user_agent` | `BSSV-Monitor/1.0` | Handy for spotting the monitor in WebLogic access logs |
| `http_proxy` / `https_proxy` | *(blank)* | Leave blank for a direct connection |

**On `verify_ssl`.** BSSV usually presents a certificate signed by an internal
CA, which Python does not trust out of the box. Shipping default is `false` so
the monitor works immediately. To do it properly: export the internal root CA as
Base-64 `.cer`, rename to `.pem`, then set `verify_ssl = true` and
`ca_bundle = C:\certs\internal-ca.pem`. With `verify_ssl = false` an expired or
swapped certificate will **not** be detected.

### `[logging]`

| Key | Default | Meaning |
|---|---|---|
| `result_log` | `logs\bssv_monitor_log.csv` | Rolling result log (opens directly in Excel) |
| `retention_hours` | `72` | **Autopurge window.** Rows older than this are removed after every pass |
| `archive_purged` | `true` | Purged rows are appended to a monthly archive instead of being lost |
| `archive_dir` | `logs\archive` | `bssv_monitor_log_YYYYMM.csv` per month |
| `app_log` | `logs\bssv_monitor.log` | Rotating application log |
| `app_log_level` | `INFO` | `DEBUG` / `INFO` / `WARNING` / `ERROR` |
| `app_log_max_bytes` / `app_log_backup_count` | `5 MB` / `5` | Rotation |
| `save_failed_responses` | `true` | Keep the raw body of failed responses for troubleshooting |
| `failed_response_dir` | `logs\responses` | Where those bodies land |
| `failed_response_retention_hours` | `72` | Those files are auto-purged too |

Result-log columns:

`run_id, timestamp_local, timestamp_utc, server_name, environment,
service_name, endpoint_url, payload_file, status, http_status, response_ms,
failure_reason, detail, attempts, email_sent`

Timestamps are written twice: `timestamp_local` for reading in Excel,
`timestamp_utc` for the arithmetic (purge window, chart buckets) — so the log
stays correct across a DST change.

### `[dashboard]`

| Key | Default | Meaning |
|---|---|---|
| `enabled` | `true` | Publish the JSON feed |
| `web_root` | `C:\inetpub\wwwroot\bssv-monitor` | **Where the dashboard is hosted.** Created if missing |
| `json_file_name` | `status.json` | Feed name inside `web_root` |
| `window_hours` | `72` | Rolling window shown |
| `copy_dashboard_files` | `true` | Copy `dashboard\index.html` into `web_root` on every pass |
| `max_detail_rows` | `1500` | Cap on individual checks embedded in the feed (~350 KB per 1000 rows). Counters and chart always cover the full window |

The feed is written to a `.tmp` file and then atomically renamed, so a browser
refreshing mid-write never reads a half-written file.

### `[email]`

| Key | Default | Meaning |
|---|---|---|
| `enabled` | `true` | Master switch for alerting |
| `powershell_script` | `send_alert.ps1` | The mailer |
| `powershell_exe` | `powershell.exe` | Use `pwsh.exe` for PowerShell 7 |
| `smtp_server` / `smtp_port` | — / `25` | Your relay |
| `use_ssl` | `false` | STARTTLS (port 587 typically) |
| `from_address` | — | Envelope sender; must be allowed to relay |
| `to_addresses` | — | Comma separated **default** recipients (fallback) |
| `cc_addresses` | *(blank)* | Comma separated |
| `subject_prefix` | `[BSSV ALERT]` | Prefix for mail rules; the environment follows it |
| `throttle_minutes` | `30` | No second alert for the same server within this window. `0` = alert every pass |
| `consolidate` | `true` | One mail listing all failures in a pass, instead of one mail each |
| `group_by_environment` | `true` | With `consolidate`, send a **separate mail per environment** so PROD keeps its own thread |
| `attach_response` | `true` | Attach the failed response body |
| `send_recovery` | `false` | Send one "RECOVERED" mail when a previously-alerting server comes back |

### `[email.recipients]` — per-environment routing

A DEV outage at 2am should not page the people who own production. Map each
`Environment` value to its own recipients:

```ini
[email.recipients]
PROD      = ops-oncall@yourcompany.com, jde-support@yourcompany.com
PRE-PROD  = jde-support@yourcompany.com
UAT       = jde-test-team@yourcompany.com
TEST      = jde-test-team@yourcompany.com
DEV       = jde-dev-team@yourcompany.com
DR        = infra-team@yourcompany.com
```

Keys are case-insensitive and every environment is optional. **Recipient
precedence, highest first:**

1. the `AlertEmailTo` cell on the server's row,
2. the matching `[email.recipients]` entry,
3. `[email] to_addresses`.

With `group_by_environment = true` (the default) a pass that breaks PROD, UAT
and DEV at once sends three separate mails — each to its own list, each with its
environment leading the subject — instead of one mail that everybody has to
read.

**Throttling matters.** With a 5-minute interval and no throttle, one server
down overnight produces ~96 e-mails. The default sends one, then one every 30
minutes while it stays down. The throttle is tracked per server, so a PROD
outage never masks a UAT one.

No password is stored anywhere. `send_alert.ps1` calls `Send-MailMessage`
without `-Credential`, so the SMTP relay must accept anonymous submission from
the monitoring host — ask your mail team to allow that host's IP on the internal
relay.

---

## 7. Running it

**Task Scheduler (recommended for production).** Set `run_mode = once` in
`config.ini`, then:

```
Program/script : C:\BSSV\bssv-monitor\run_once.bat
Start in       : C:\BSSV\bssv-monitor
Trigger        : Daily, repeat every 5 minutes, for a duration of 1 day
Settings       : Run whether user is logged on or not
                 If the task is already running, do not start a new instance
```

Task Scheduler survives reboots and restarts a crashed pass. This is the safer
choice for an unattended server.

**Resident loop.** Set `run_mode = loop` and run `run_loop.bat`. Useful during
setup because everything is visible on the console. To make it a real service,
wrap it with [NSSM](https://nssm.cc):

```bat
nssm install BSSVMonitor "C:\BSSV\bssv-monitor\run_loop.bat"
nssm set BSSVMonitor AppDirectory C:\BSSV\bssv-monitor
nssm start BSSVMonitor
```

**Command-line flags** (they override `config.ini`):

```bat
python bssv_monitor.py --once            :: one pass, then exit
python bssv_monitor.py --loop            :: stay resident
python bssv_monitor.py --once --dry-run  :: probe and log, never send e-mail
python bssv_monitor.py --once --verbose  :: debug output on the console
python bssv_monitor.py --test-email      :: send a test alert and exit
python bssv_monitor.py --config D:\alt\config.ini
```

---

## 8. Hosting the dashboard

The dashboard is a **single static HTML file** that reads `status.json` from the
same folder. No PHP, no ASP.NET, no backend — it works identically in IIS and
XAMPP. It refreshes itself every **60 seconds** and shows the rolling
**72 hours**:

* an **environment selector** across the top — `All` plus one chip per
  environment, each showing its check count and a red dot when a server in it is
  down. Picking one rescopes the entire page: counters, chart, server grid and
  history. The choice is remembered in the browser, so a screen mounted on the
  wall can sit permanently on PROD;
* All / Success / Failed counters and the success rate for the selected scope;
* an hourly success-vs-failure chart, redrawn per environment;
* a server grid **grouped by environment**, production first, with uptime %,
  check count, failure count and average response time per server;
* the full check history **newest first**, with All / Success / Failed filters,
  a search box, and an environment tag on every row.

### IIS

1. Set `web_root = C:\inetpub\wwwroot\bssv-monitor` in `config.ini`.
2. Run one pass — the folder, `index.html` and `status.json` are created.
3. IIS Manager → *Sites* → *Default Web Site* → **Add Application**
   (alias `bssv-monitor`, physical path as above), or just browse the folder
   under the default site.
4. Make sure the `.json` MIME type exists: IIS Manager → the site → **MIME
   Types** → add `.json` = `application/json` if it is missing.
5. Browse to `http://<server>/bssv-monitor/`.

Give the account running the monitor **write** permission on that folder, and
`IIS_IUSRS` **read**.

### XAMPP

1. Set `web_root = C:\xampp\htdocs\bssv-monitor`.
2. Run one pass, start Apache, browse to
   `http://localhost/bssv-monitor/`.

### Anywhere else

Any static web server will do. The one thing that does **not** work is opening
`index.html` from disk with a `file://` URL — browsers block the `fetch` of
`status.json` from the filesystem. Serve it over HTTP.

---

## 9. Verifying the setup

Work through these in order; each one isolates a different link in the chain.

```bat
:: 1. Are the check folders and servers.csv wired up, and the endpoints
::    reachable? Prints every config warning. No mail sent.
python bssv_monitor.py --once --dry-run --verbose

:: 2. Does the SMTP relay accept our mail?
python bssv_monitor.py --test-email

:: 3. Full pass with alerting live.
python bssv_monitor.py --once
```

The dry run is where you fix configuration: it prints one line per check
folder found, one per endpoint probed, and a warning for every dead CSV row,
missing `Environment`, incomplete check folder and suspect `ExpectedText`
value. Get it to run clean before scheduling it.

Then check:

* `logs\bssv_monitor_log.csv` has one row per enabled endpoint.
* `<web_root>\status.json` exists and its `generated_at_local` is recent.
* The dashboard loads over HTTP and the counters match the CSV.

A quick negative test: add a row pointing at a deliberately wrong port, run one
pass, and confirm the alert arrives and the row shows up red on the dashboard.

---

## 10. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `Checks folder not found` | `checks_dir` is wrong, or the `checks\` folder was not copied |
| `Nothing to probe` | No check folder produced a usable URL + `request.xml` + Environment. Run with `--dry-run --verbose` and read the warnings |
| `Check 'X' skipped - no request.xml` / `no BSSV_URL.txt` | That folder is incomplete. Both files are required |
| `servers.csv row N matches no URL in any BSSV_URL.txt` | Dead row — the URL differs from the one in the check folder. Compare them character by character; the join is exact (trailing `/` and case are ignored) |
| `<Check> -> <url> skipped - no Environment` | Add a `servers.csv` row for that URL, or `environment=` in the check's `check.ini` |
| `Server list not found` | The `server_list` path is wrong. Not fatal — every URL falls back to `check.ini` |
| `has no EndpointURL column` | The header was renamed. `EndpointURL` is the only mandatory column — it is the join key |
| A row gains extra columns, or `AlertEmailTo` looks truncated | An unquoted comma in the CSV. Wrap the cell: `"a@x.com,b@x.com"` |
| Every `SOAPAction` shows as `""""""` | You typed the escaped form into the CSV. Leave the cell blank — it inherits `default_soap_action` |
| `...is a workbook, which needs openpyxl` | `server_list` points at an `.xlsx`. Either `pip install openpyxl` or switch back to CSV |
| A server is missing from the dashboard | Its environment is not the one currently selected. Click **All** in the environment bar |
| The wrong team got the alert | Check the precedence in §6: an `AlertEmailTo` cell beats `[email.recipients]`, which beats `to_addresses`. Also check the environment spelling — `PRD` and `PROD` are different environments |
| Every server reports `SOAP_FAULT` with "Invalid user or password" | The credentials in the payload XML are wrong or the E1 account is locked/expired |
| `SSL_ERROR` on every server | Internal CA not trusted. Either set `ca_bundle`, or set `verify_ssl = false` |
| `CONNECTION_ERROR` from the monitoring host only | Firewall between the host and the BSSV port (7251/7253/7851 …). Test with `Test-NetConnection <host> -Port 7851` |
| `HTTP_STATUS 404` | Wrong path segment — the environment code (`DV920`, `PD920OR`) or the service name is wrong in `EndpointURL` |
| `EXPECTED_TEXT_MISSING` but the service looks fine | The value is wrong for this operation. Blank the cell, run once, and read the saved body in `logs\responses\` to pick a real marker. If `responds.xml` is present the startup warning usually catches this first |
| Two endpoints share one dashboard card | They have the same `ServerName`, `Environment` **and** `ServiceName`. Give them distinct `ServerName` values in `servers.csv` |
| No alert e-mail, log says `MAIL FAILED` | Relay rejected the message. Test by hand: `Send-MailMessage -SmtpServer <relay> -From <from> -To <you> -Subject test -Body test` |
| No alert and no error | Throttled. Check `logs\alert_state.json`, or set `throttle_minutes = 0` while testing |
| `PowerShell executable not found` | Set `powershell_exe` to the full path, e.g. `C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe` |
| Dashboard shows "Could not load status.json" | The feed is not in `web_root`, the site is not serving `.json`, or you opened the file with `file://` |
| Dashboard never updates | The monitor is not running, or `web_root` points somewhere the web server does not serve |
| CSV keeps growing past 72 hours | `retention_hours` was raised, or the file is held open by Excel so the rewrite fails — check `logs\bssv_monitor.log` |

---

## 11. Operating notes

* **Interval.** 5 minutes (`300`) is a sensible default: fast enough to catch an
  outage, gentle enough on a production E1 server. Below 60 seconds you are
  load-testing your own BSSV instance.
* **Retention.** 72 hours is the dashboard window. Raise `retention_hours` and
  `window_hours` together if you want a longer view, and keep an eye on
  `max_detail_rows` — the feed is re-downloaded by every open browser tab every
  60 seconds.
* **Archive.** With `archive_purged = true` nothing is actually lost: the
  monthly CSVs under `logs\archive\` hold the full history for trend reporting.
* **Clock.** Chart buckets and the purge window use UTC internally and display
  local time, so a DST shift does not distort the 72-hour window.
* **Concurrency.** `max_workers = 4` probes four servers at once. Set it to `1`
  if your BSSV instance is sensitive to parallel sessions.
* **Read-only probes only.** Never point a payload at a write operation
  (`addAddressBook`, order entry …) — the monitor runs unattended, forever.

---

## 12. Extending it

* **New service:** make a folder under `checks\`, drop in `BSSV_URL.txt` and
  `request.xml`, add a `servers.csv` row per URL. No code change, no restart.
* **New environment:** add its URL to the check's `BSSV_URL.txt` and a
  `servers.csv` row naming the new `Environment`. If it needs different
  credentials, make a second check folder instead — `request.xml` carries the
  credentials for every URL beside it. The environment appears in
  the dashboard selector and the alert subject on the next pass; add an
  `[email.recipients]` line if it needs its own distribution list. The seven
  codes in the dropdown are only a convenience — typing `PY920` or `JPD` works
  exactly the same, it just will not get the production tint or the top sort
  slot unless it is one of `PROD` / `PRODUCTION` / `PRD` / `LIVE`.
* **Different success rule:** the entire rule lives in `evaluate()` in
  `bssv_monitor.py` (about 15 lines).
* **Different alert channel:** `send_alert.ps1` is called with plain arguments
  (`-SmtpServer -Port -From -To -Subject -BodyFile`). Swap its body for a Teams
  webhook or a ticket-system call and the Python side does not change.
