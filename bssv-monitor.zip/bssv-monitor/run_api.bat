@echo off
REM ---------------------------------------------------------------------
REM  BSSV Monitor - backend API service for the DT-SHDLR and onetimerun
REM  web pages. Leave this running; the pages call it from IIS.
REM
REM  As a Windows service (survives reboots), wrap it with NSSM:
REM      nssm install BSSVMonitorApi "C:\BSSV\bssv-monitor\run_api.bat"
REM      nssm set BSSVMonitorApi AppDirectory C:\BSSV\bssv-monitor
REM      nssm start BSSVMonitorApi
REM ---------------------------------------------------------------------
setlocal
cd /d "%~dp0"
title BSSV Monitor API
python bssv_api.py
