#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BSSV Monitor - backend API service
==================================

The two web pages (DT-SHDLR and onetimerun) need things a static page cannot
do: write a config file, and actually POST a SOAP request. IIS serving plain
HTML does neither, so this small service provides them.

It runs on the SAME host as bssv_monitor.py, because it reuses that script's
own code - the check folders, servers.csv, the probe and the success rule are
all imported from it. A "Test Now" from the web page therefore behaves exactly
like a scheduled check; there is no second implementation to drift.

    python bssv_api.py                 # serve on the configured port
    python bssv_api.py --port 8787
    python bssv_api.py --once-check    # verify config and exit (no serving)

Endpoints
---------
    GET  /api/health                 service + config summary
    GET  /api/targets                environments and servers, for the dropdowns
    GET  /api/downtime               the downtime windows
    POST /api/downtime               replace the downtime windows (validated)
    GET  /api/recipients             alert addresses, and where each comes from
    POST /api/recipients             replace the alert addresses (validated)
    POST /api/test-email             send a sample alert to the saved addresses
    POST /api/test                   run ONE check now, return the result
    GET  /api/session/<id>           re-read a past one-time result (24h)

It also serves the pages themselves, so if IIS is unavailable you can reach
everything on this port alone:

    /                 the dashboard  (dashboard_local)
    /DT-SHDLR/        the downtime scheduler
    /onetimerun/      the one-time test page
    /alerts/          the alert recipients page

Standard library only. No dependencies beyond what bssv_monitor.py already
needs.
"""

from __future__ import annotations

import argparse
import json
import mimetypes
import os
import posixpath
import re
import sys
import threading
import time
import traceback
import urllib.parse
import uuid
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

try:
    import bssv_monitor as bm
except ImportError as exc:  # pragma: no cover
    sys.exit(f"Could not import bssv_monitor.py from {BASE_DIR}: {exc}")

APP_NAME = "BSSV Monitor API"
APP_VERSION = "1.0.0"

MAX_BODY_BYTES = 1 * 1024 * 1024        # a downtime config is tiny; cap the rest
SESSION_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")

# downtime.json is read-modify-written by several browsers at once.
_downtime_lock = threading.Lock()
_purge_lock = threading.Lock()
_purge_running = False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def load_config(path: str = "") -> "bm.Config":
    return bm.Config(path or os.path.join(BASE_DIR, "config.ini"))


def session_dir(cfg) -> str:
    return getattr(cfg, "session_dir", os.path.join(BASE_DIR, "logs", "sessions"))


# ---------------------------------------------------------------------------
# Session store  (one JSON per one-time run, purged after 24h)
# ---------------------------------------------------------------------------
def write_session(cfg, session_id: str, payload: dict) -> str:
    folder = session_dir(cfg)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"{session_id}.json")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=1, ensure_ascii=False)
    os.replace(tmp, path)
    return path


def read_session(cfg, session_id: str):
    if not SESSION_ID_RE.match(session_id or ""):
        return None
    path = os.path.join(session_dir(cfg), f"{session_id}.json")
    # Guard against a crafted id escaping the folder.
    if os.path.dirname(os.path.abspath(path)) != os.path.abspath(session_dir(cfg)):
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def purge_sessions(cfg) -> int:
    """Delete session files older than the retention window."""
    folder = session_dir(cfg)
    if not os.path.isdir(folder):
        return 0
    hours = getattr(cfg, "session_retention_hours", 24)
    cutoff = time.time() - hours * 3600
    removed = 0
    for name in os.listdir(folder):
        if not name.endswith(".json"):
            continue
        path = os.path.join(folder, name)
        try:
            if os.path.isfile(path) and os.path.getmtime(path) < cutoff:
                os.remove(path)
                removed += 1
        except OSError:
            pass
    return removed


def purge_sessions_async(cfg) -> None:
    """
    Fire the purge on a background thread so the user's Test Now never waits
    on housekeeping.

    Coalesced rather than time-throttled: if a purge is already in flight we
    skip, because that run will sweep the same folder anyway. A time-based
    throttle was wrong here - two tests a minute apart would leave stale
    sessions on disk, when the whole point is that a test triggers the sweep.
    """
    global _purge_running

    with _purge_lock:
        if _purge_running:
            return
        _purge_running = True

    def worker():
        global _purge_running
        try:
            removed = purge_sessions(cfg)
            if removed:
                bm.log.info("Session purge: removed %s file(s) older than %sh",
                            removed, getattr(cfg, "session_retention_hours", 24))
        except Exception:  # noqa: BLE001
            bm.log.debug("Session purge failed:\n%s", traceback.format_exc())
        finally:
            with _purge_lock:
                _purge_running = False

    threading.Thread(target=worker, name="session-purge", daemon=True).start()


# ---------------------------------------------------------------------------
# Downtime read / validate / write
# ---------------------------------------------------------------------------
VALID_SCOPES = ("all", "environment", "server")
VALID_TYPES = ("recurring", "once")


def validate_downtime(data) -> tuple:
    """
    Returns (cleaned, errors). Anything malformed is rejected rather than
    silently dropped - a window that does not do what the operator typed is
    worse than no window, because they will trust it.
    """
    errors = []
    if not isinstance(data, dict):
        return None, ["Body must be a JSON object."]

    raw = data.get("windows")
    if raw is None:
        raw = []
    if not isinstance(raw, list):
        return None, ["'windows' must be a list."]

    cleaned, seen_ids = [], set()

    for index, item in enumerate(raw):
        label = f"window {index + 1}"
        if not isinstance(item, dict):
            errors.append(f"{label}: must be an object.")
            continue

        name = str(item.get("name", "")).strip()
        if not name:
            errors.append(f"{label}: needs a name.")

        kind = str(item.get("type", "recurring")).strip().lower()
        if kind not in VALID_TYPES:
            errors.append(f"{label}: type must be 'recurring' or 'once'.")
            continue

        scope = str(item.get("scope", "all")).strip().lower()
        if scope not in VALID_SCOPES:
            errors.append(f"{label}: scope must be all / environment / server.")
            continue

        target = str(item.get("target", "")).strip()
        if scope != "all" and not target:
            errors.append(f"{label}: scope '{scope}' needs a target.")

        window_id = str(item.get("id", "")).strip() or uuid.uuid4().hex[:12]
        if window_id in seen_ids:
            window_id = uuid.uuid4().hex[:12]
        seen_ids.add(window_id)

        entry = {
            "id": window_id,
            "enabled": bool(item.get("enabled", True)),
            "name": name,
            "type": kind,
            "scope": scope,
            "target": target if scope != "all" else "",
            "notes": str(item.get("notes", "")).strip()[:500],
        }

        if kind == "recurring":
            days = item.get("days") or []
            if not isinstance(days, list):
                errors.append(f"{label}: days must be a list.")
                continue
            days = [str(d).strip().upper()[:3] for d in days]
            days = [d for d in days if d in bm.DAY_KEYS]
            if not days:
                errors.append(f"{label}: pick at least one day.")
            start = str(item.get("start_time", "")).strip()
            end = str(item.get("end_time", "")).strip()
            if bm._parse_hhmm(start) is None:
                errors.append(f"{label}: start time '{start}' is not HH:MM.")
            if bm._parse_hhmm(end) is None:
                errors.append(f"{label}: end time '{end}' is not HH:MM.")
            if bm._parse_hhmm(start) is not None and bm._parse_hhmm(start) == bm._parse_hhmm(end):
                errors.append(f"{label}: start and end time are the same.")
            entry.update({"days": days, "start_time": start, "end_time": end})
        else:
            start = str(item.get("start", "")).strip()
            end = str(item.get("end", "")).strip()
            sdt, edt = bm._parse_local(start), bm._parse_local(end)
            if sdt is None:
                errors.append(f"{label}: start '{start}' is not a valid date/time.")
            if edt is None:
                errors.append(f"{label}: end '{end}' is not a valid date/time.")
            if sdt and edt and edt <= sdt:
                errors.append(f"{label}: end must be after start.")
            entry.update({"start": start, "end": end})

        cleaned.append(entry)

    if errors:
        return None, errors

    return {
        "version": 1,
        "updated_at_local": bm.iso_local(now_utc()),
        "updated_at_utc": bm.iso_utc(now_utc()),
        "updated_by": str(data.get("updated_by", "")).strip()[:120],
        "windows": cleaned,
    }, []


def save_downtime(cfg, payload: dict) -> None:
    """Atomic write, keeping one backup of the previous version."""
    path = cfg.downtime_file
    with _downtime_lock:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        if os.path.isfile(path):
            try:
                backup = path + ".bak"
                with open(path, "r", encoding="utf-8-sig") as src:
                    previous = src.read()
                with open(backup, "w", encoding="utf-8") as dst:
                    dst.write(previous)
            except OSError:
                pass
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=1, ensure_ascii=False)
        os.replace(tmp, path)


# ---------------------------------------------------------------------------
# Alert recipients
#
# The page edits two of the four precedence levels: the per-environment lists
# and the global default. Level 1 (the AlertEmailTo cell in servers.csv) and
# level 2 (alert_email_to in a check.ini) are deliberately NOT editable here -
# they are per-server exceptions that belong with the server definition. They
# are returned read-only so the operator can see which servers bypass whatever
# they are about to change.
# ---------------------------------------------------------------------------
EMAIL_RE = re.compile(r"^[^@\s,;<>]+@[^@\s,;<>]+\.[^@\s,;<>]{2,}$")

# One browser saving while another reads would otherwise interleave.
_recipients_lock = threading.Lock()


def split_addresses(text: str) -> list:
    """Accept comma, semicolon or newline separated input; return a clean list."""
    if not text:
        return []
    parts = re.split(r"[,;\r\n]+", str(text))
    seen, out = set(), []
    for part in parts:
        value = part.strip().strip("<>").strip()
        if not value:
            continue
        key = value.lower()
        if key in seen:          # a duplicate address means a duplicate mail
            continue
        seen.add(key)
        out.append(value)
    return out


def check_addresses(text: str, label: str, errors: list) -> str:
    """Validate a free-text address list and return it normalised."""
    addresses = split_addresses(text)
    for address in addresses:
        if not EMAIL_RE.match(address):
            errors.append(f"{label}: '{address}' is not a valid e-mail address.")
    if len(addresses) > 50:
        errors.append(f"{label}: more than 50 addresses - use a distribution list.")
    return ", ".join(addresses)


def csv_level_overrides(cfg) -> list:
    """
    Servers whose AlertEmailTo cell (or check.ini) sets their own address, so
    the page can warn that these ignore what it manages.
    """
    out = []
    try:
        targets = bm.build_targets(cfg)
    except Exception as exc:  # noqa: BLE001
        bm.log.debug("Could not list per-server overrides: %s", exc)
        return out

    env_lists = {k.upper(): v for k, v in (cfg.env_recipients or {}).items()}
    for target in targets:
        to = (target.get("alert_email_to") or "").strip()
        if not to:
            continue
        # build_targets() already folded the fallbacks in, so an address equal to
        # the environment list or the global default is NOT a per-server override.
        env = (target.get("environment") or "").upper()
        if to == (env_lists.get(env) or "").strip() or to == (cfg.to_addresses or "").strip():
            continue
        out.append({
            "server_name": target["server_name"],
            "environment": target["environment"],
            "service_name": target["service_name"],
            "to": to,
        })
    return sorted(out, key=lambda r: (r["environment"], r["server_name"].lower()))


def build_recipients_view(cfg) -> dict:
    """Everything the Alerts page needs: current values, their origin, context."""
    stored = bm.load_recipients(cfg)

    file_envs = {}
    order = []
    for row in stored.get("environments") or []:
        if not isinstance(row, dict):
            continue
        env = str(row.get("environment") or "").strip().upper()
        if not env:
            continue
        if env not in file_envs:
            order.append(env)
        file_envs[env] = {
            "environment": env,
            "to": str(row.get("to") or "").strip(),
            "enabled": bool(row.get("enabled", True)),
            "source": "file",
        }

    # config.ini entries the file does not mention are shown too, marked as such,
    # so nothing routing mail today is invisible on the page.
    rows = []
    for env in order:
        rows.append(file_envs[env])
    for env, to in sorted((cfg.ini_env_recipients or {}).items()):
        if env not in file_envs:
            rows.append({"environment": env, "to": to, "enabled": True,
                         "source": "config.ini"})

    # Environments that exist in servers.csv, for the "add row" dropdown.
    known = []
    try:
        known = [e["name"] for e in build_target_list(cfg)["environments"]]
    except Exception as exc:  # noqa: BLE001
        bm.log.debug("Could not list environments: %s", exc)

    has_file = bool(cfg.recipients_file) and os.path.isfile(cfg.recipients_file)
    return {
        "enabled": bool(getattr(cfg, "recipients_from_file", True)),
        "file": cfg.recipients_file,
        "has_file": has_file,
        "source": "recipients.json" if has_file else "config.ini",
        "updated_at_local": stored.get("updated_at_local", ""),
        "updated_by": stored.get("updated_by", ""),
        "default_to": (stored.get("default_to") or cfg.ini_to_addresses or "").strip(),
        "default_cc": (
            stored.get("default_cc", cfg.ini_cc_addresses) or ""
        ).strip(),
        "ini_default_to": cfg.ini_to_addresses,
        "ini_default_cc": cfg.ini_cc_addresses,
        "environments": rows,
        "known_environments": known,
        "server_overrides": csv_level_overrides(cfg),
        # Read-only context - these stay in config.ini by design.
        "email_enabled": bool(cfg.email_enabled),
        "from_address": cfg.from_address,
        "smtp_server": cfg.smtp_server,
        "smtp_port": cfg.smtp_port,
        "use_ssl": bool(cfg.use_ssl),
        "subject_prefix": cfg.subject_prefix,
        "throttle_minutes": cfg.throttle_minutes,
        "group_by_environment": bool(cfg.group_by_environment),
    }


def validate_recipients(data) -> tuple:
    """Returns (cleaned, errors). A bad address is rejected, never dropped."""
    errors = []
    if not isinstance(data, dict):
        return None, ["Body must be a JSON object."]

    default_to = check_addresses(data.get("default_to", ""), "Default recipients", errors)
    default_cc = check_addresses(data.get("default_cc", ""), "Default CC", errors)

    if not default_to:
        errors.append(
            "Default recipients cannot be empty - it is the fallback for every "
            "environment that has no entry of its own."
        )

    raw = data.get("environments")
    if raw is None:
        raw = []
    if not isinstance(raw, list):
        return None, ["'environments' must be a list."]

    cleaned_envs, seen = [], set()
    for index, item in enumerate(raw):
        label = f"row {index + 1}"
        if not isinstance(item, dict):
            errors.append(f"{label}: must be an object.")
            continue
        env = str(item.get("environment", "")).strip().upper()
        if not env:
            errors.append(f"{label}: needs an environment name.")
            continue
        if env in seen:
            errors.append(f"{env}: listed twice - keep one row per environment.")
            continue
        seen.add(env)
        to = check_addresses(item.get("to", ""), env, errors)
        enabled = bool(item.get("enabled", True))
        if enabled and not to:
            errors.append(f"{env}: no address. Add one, or switch the row off.")
        cleaned_envs.append({"environment": env, "to": to, "enabled": enabled})

    if errors:
        return None, errors

    return {
        "version": 1,
        "updated_at_local": bm.iso_local(now_utc()),
        "updated_at_utc": bm.iso_utc(now_utc()),
        "updated_by": str(data.get("updated_by", "")).strip()[:120],
        "default_to": default_to,
        "default_cc": default_cc,
        "environments": cleaned_envs,
    }, []


def save_recipients(cfg, payload: dict) -> None:
    """Atomic write, keeping one backup of the previous version."""
    path = cfg.recipients_file
    with _recipients_lock:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8-sig") as src:
                    previous = src.read()
                with open(path + ".bak", "w", encoding="utf-8") as dst:
                    dst.write(previous)
            except OSError:
                pass
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=1, ensure_ascii=False)
        os.replace(tmp, path)


def send_test_email(cfg, environment: str = "") -> dict:
    """
    Send a sample alert to the addresses currently in force. Only addresses the
    configuration already holds are used - the page cannot mail an arbitrary
    address, which keeps this from becoming an open relay form.
    """
    bm.apply_recipients(cfg)

    environment = (environment or "").strip().upper()
    if environment:
        to = (cfg.env_recipients.get(environment) or "").strip()
        if not to:
            to = cfg.to_addresses
            routed = f"{environment} has no entry of its own, so the default list was used"
        else:
            routed = f"the {environment} list"
    else:
        to = cfg.to_addresses
        routed = "the default list"

    if not to:
        return {"sent": False, "to": "", "routed_via": routed,
                "message": "No recipients are configured."}
    if not (cfg.smtp_server and cfg.from_address):
        return {"sent": False, "to": to, "routed_via": routed,
                "message": "smtp_server / from_address are not set in config.ini."}

    sample = {
        "server_name": "TEST-SERVER",
        "environment": environment or "TEST",
        "service_name": "RI_AddressBookManager",
        "endpoint_url": "https://example.invalid/PD920/RI_AddressBookManager",
        "failure_reason": "TEST_ALERT",
        "detail": "Test message sent from the BSSV Monitor Alerts page. "
                  "No server actually failed.",
        "http_status": "000", "response_ms": "0", "attempts": 1,
    }
    subject = f"{cfg.subject_prefix} Test alert"
    if environment:
        subject = f"{cfg.subject_prefix} Test alert - {environment}"

    try:
        ok = bm.send_mail(cfg, subject, bm.build_alert_html(cfg, [sample], "test"), to, [])
    except Exception as exc:  # noqa: BLE001
        bm.log.error("Test e-mail failed:\n%s", traceback.format_exc())
        return {"sent": False, "to": to, "routed_via": routed,
                "message": f"{type(exc).__name__}: {exc}"}

    return {
        "sent": bool(ok),
        "to": to,
        "routed_via": routed,
        "from_address": cfg.from_address,
        "smtp_server": f"{cfg.smtp_server}:{cfg.smtp_port}",
        "message": "Sent. Check the inbox - and the junk folder."
                   if ok else "The send failed. See app.log for the SMTP error.",
    }


# ---------------------------------------------------------------------------
# Targets (the dropdown source) and the one-time test
# ---------------------------------------------------------------------------
def build_target_list(cfg) -> dict:
    """Environments -> servers, straight from servers.csv + the check folders."""
    targets = bm.build_targets(cfg)

    by_env = {}
    for target in targets:
        env = target["environment"]
        by_env.setdefault(env, []).append({
            "server_name": target["server_name"],
            "service_name": target["service_name"],
            "endpoint_url": target["endpoint_url"],
            "check_name": target["check_name"],
            "environment": env,
        })

    ranking = ["PROD", "PRODUCTION", "PRD", "LIVE", "PRE-PROD", "PREPROD",
               "DR", "UAT", "TEST", "QA", "DEV", "TRAINING"]

    def env_key(name):
        upper = (name or "").upper()
        return (ranking.index(upper) if upper in ranking else len(ranking), upper)

    environments = []
    for env in sorted(by_env, key=env_key):
        servers = sorted(by_env[env], key=lambda s: s["server_name"].lower())
        environments.append({"name": env, "servers": servers})

    return {
        "generated_at_local": bm.iso_local(now_utc()),
        "environments": environments,
        "total_endpoints": len(targets),
    }


def run_one_test(cfg, environment: str, server_name: str, service_name: str = "") -> dict:
    """
    Probe exactly one endpoint, using the monitor's own code so the verdict
    matches what a scheduled pass would decide. Nothing is written to the
    result log - this is deliberately off the record.
    """
    matches = [
        t for t in bm.build_targets(cfg)
        if t["environment"].upper() == (environment or "").upper()
        and t["server_name"].lower() == (server_name or "").lower()
        and (not service_name or t["service_name"].lower() == service_name.lower())
    ]
    if not matches:
        raise LookupError(
            f"No endpoint found for environment '{environment}' and server '{server_name}'."
        )

    target = matches[0]
    run_id = "onetime-" + uuid.uuid4().hex[:8]

    session = bm.build_session(cfg)
    try:
        result = bm.probe(cfg, session, target, run_id)
    finally:
        session.close()

    body = result.pop("_body", "") or ""
    result.pop("_alert_to", None)
    result.pop("_response_file", None)

    # Say so when the endpoint is inside a downtime window - the test still
    # runs (the operator asked for it), but the answer needs that context.
    window = bm.active_window_for(bm.load_downtime(cfg), target)

    return {
        "environment": target["environment"],
        "server_name": target["server_name"],
        "service_name": target["service_name"],
        "endpoint_url": target["endpoint_url"],
        "check_name": target["check_name"],
        "expected_text": target["expected_text"],
        "timeout_seconds": target["timeout_seconds"],
        "status": result["status"],
        "http_status": result["http_status"],
        "response_ms": bm.as_int(result["response_ms"], 0),
        "failure_reason": result["failure_reason"],
        "detail": result["detail"],
        "attempts": result["attempts"],
        "tested_at_local": result["timestamp_local"],
        "tested_at_utc": result["timestamp_utc"],
        "in_downtime": bool(window),
        "downtime_window": bm.describe_window(window) if window else "",
        "response_body": body[:200000],
        "response_bytes": len(body),
    }


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = f"BSSVMonitorAPI/{APP_VERSION}"
    protocol_version = "HTTP/1.1"

    # -- plumbing -----------------------------------------------------------
    def log_message(self, fmt, *args):     # quieter than the default
        bm.log.debug("api %s - %s", self.address_string(), fmt % args)

    @property
    def cfg(self):
        return self.server.cfg

    def _cors(self):
        allowed = getattr(self.cfg, "allow_origins", "*") or "*"
        origin = self.headers.get("Origin", "")
        if allowed.strip() == "*":
            self.send_header("Access-Control-Allow-Origin", "*")
        else:
            permitted = [o.strip() for o in allowed.split(",") if o.strip()]
            if origin and origin in permitted:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")

    def send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False, indent=1).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def send_error_json(self, status, message, extra=None):
        payload = {"ok": False, "error": message}
        if extra:
            payload.update(extra)
        self.send_json(payload, status)

    def read_body(self):
        length = bm.as_int(self.headers.get("Content-Length"), 0)
        if length <= 0:
            return {}
        if length > MAX_BODY_BYTES:
            raise ValueError("Request body too large.")
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise ValueError(f"Body is not valid JSON: {exc}")

    # -- verbs --------------------------------------------------------------
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        try:
            if path == "/api/health":
                return self.send_json({
                    "ok": True,
                    "service": APP_NAME,
                    "version": APP_VERSION,
                    "monitor_config": self.cfg.path,
                    "downtime_file": self.cfg.downtime_file,
                    "server_time_local": bm.iso_local(now_utc()),
                    "session_retention_hours": getattr(self.cfg, "session_retention_hours", 24),
                })

            if path == "/api/targets":
                return self.send_json({"ok": True, **build_target_list(self.cfg)})

            if path == "/api/downtime":
                data = bm.load_downtime(self.cfg)
                now_local = datetime.now()
                for window in data.get("windows", []):
                    window["active_now"] = bm.window_active(window, now_local)
                return self.send_json({"ok": True, **data})

            if path == "/api/recipients":
                # Overlay first so the page always shows what is actually in force,
                # including anything edited straight in recipients.json.
                bm.apply_recipients(self.cfg)
                return self.send_json({"ok": True, **build_recipients_view(self.cfg)})

            if path.startswith("/api/session/"):
                session_id = path.rsplit("/", 1)[-1]
                payload = read_session(self.cfg, session_id)
                if payload is None:
                    return self.send_error_json(
                        404, "That session was not found - results are kept for "
                             f"{getattr(self.cfg, 'session_retention_hours', 24)} hours."
                    )
                return self.send_json({"ok": True, **payload})

            if path.startswith("/api/"):
                return self.send_error_json(404, f"Unknown endpoint: {path}")

            return self.serve_static(path)

        except Exception as exc:  # noqa: BLE001
            bm.log.error("API GET %s failed:\n%s", path, traceback.format_exc())
            return self.send_error_json(500, f"{type(exc).__name__}: {exc}")

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        try:
            if path == "/api/downtime":
                try:
                    body = self.read_body()
                except ValueError as exc:
                    return self.send_error_json(400, str(exc))

                cleaned, errors = validate_downtime(body)
                if errors:
                    return self.send_error_json(
                        400, "The downtime configuration was not saved.",
                        {"problems": errors},
                    )
                save_downtime(self.cfg, cleaned)
                bm.log.info(
                    "Downtime configuration saved - %s window(s)%s",
                    len(cleaned["windows"]),
                    f" by {cleaned['updated_by']}" if cleaned["updated_by"] else "",
                )
                now_local = datetime.now()
                for window in cleaned["windows"]:
                    window["active_now"] = bm.window_active(window, now_local)
                return self.send_json({"ok": True, **cleaned})

            if path == "/api/recipients":
                try:
                    body = self.read_body()
                except ValueError as exc:
                    return self.send_error_json(400, str(exc))

                cleaned, errors = validate_recipients(body)
                if errors:
                    return self.send_error_json(
                        400, "The recipients were not saved.", {"problems": errors},
                    )
                save_recipients(self.cfg, cleaned)
                bm.apply_recipients(self.cfg)
                bm.log.info(
                    "Alert recipients saved - default '%s', %s environment row(s)%s",
                    cleaned["default_to"], len(cleaned["environments"]),
                    f" by {cleaned['updated_by']}" if cleaned["updated_by"] else "",
                )
                return self.send_json({"ok": True, **build_recipients_view(self.cfg)})

            if path == "/api/test-email":
                try:
                    body = self.read_body()
                except ValueError as exc:
                    return self.send_error_json(400, str(exc))
                if not self.cfg.email_enabled:
                    return self.send_error_json(
                        409, "E-mail is switched off in config.ini ([email] enabled = false)."
                    )
                outcome = send_test_email(self.cfg, str(body.get("environment", "")))
                bm.log.info(
                    "Test e-mail requested from the Alerts page -> %s (%s)",
                    outcome["to"] or "nobody", "sent" if outcome["sent"] else "FAILED",
                )
                return self.send_json({"ok": True, **outcome})

            if path == "/api/test":
                try:
                    body = self.read_body()
                except ValueError as exc:
                    return self.send_error_json(400, str(exc))

                environment = str(body.get("environment", "")).strip()
                server_name = str(body.get("server_name", "")).strip()
                service_name = str(body.get("service_name", "")).strip()
                if not environment or not server_name:
                    return self.send_error_json(
                        400, "Both environment and server_name are required."
                    )

                # Housekeeping first, on its own thread - the user never waits.
                purge_sessions_async(self.cfg)

                session_id = uuid.uuid4().hex
                started = time.time()
                try:
                    outcome = run_one_test(self.cfg, environment, server_name, service_name)
                except LookupError as exc:
                    return self.send_error_json(404, str(exc))

                payload = {
                    "session_id": session_id,
                    "created_at_local": bm.iso_local(now_utc()),
                    "created_at_utc": bm.iso_utc(now_utc()),
                    "expires_at_local": bm.iso_local(
                        now_utc() + timedelta(
                            hours=getattr(self.cfg, "session_retention_hours", 24)
                        )
                    ),
                    "requested_by": str(body.get("requested_by", "")).strip()[:120],
                    "elapsed_ms": int((time.time() - started) * 1000),
                    "result": outcome,
                }
                try:
                    write_session(self.cfg, session_id, payload)
                except OSError as exc:
                    bm.log.error("Could not write session %s: %s", session_id, exc)

                bm.log.info(
                    "One-time test %s: %s / %s -> %s",
                    session_id[:8], outcome["environment"], outcome["server_name"],
                    outcome["status"],
                )
                return self.send_json({"ok": True, **payload})

            return self.send_error_json(404, f"Unknown endpoint: {path}")

        except Exception as exc:  # noqa: BLE001
            bm.log.error("API POST %s failed:\n%s", path, traceback.format_exc())
            return self.send_error_json(500, f"{type(exc).__name__}: {exc}")

    # -- static pages -------------------------------------------------------
    STATIC_ROOTS = {
        "/DT-SHDLR": "DT-SHDLR",
        "/onetimerun": "onetimerun",
        "/alerts": "alerts",
    }

    def serve_static(self, path: str):
        """
        Serve the two pages (and the dashboard) so everything is reachable on
        this port alone when IIS is not an option.
        """
        clean = posixpath.normpath(urllib.parse.unquote(path))
        if ".." in clean.split("/"):
            return self.send_error_json(403, "Forbidden")

        relative = None
        for prefix, folder in self.STATIC_ROOTS.items():
            if clean.lower() == prefix.lower() or clean.lower().startswith(prefix.lower() + "/"):
                rest = clean[len(prefix):].lstrip("/") or "index.html"
                relative = os.path.join(folder, rest)
                break

        if relative is None:
            rest = clean.lstrip("/") or "index.html"
            local_root = getattr(self.cfg, "local_web_root", "") or os.path.join(BASE_DIR, "dashboard")
            candidate = os.path.join(local_root, rest)
            if os.path.isfile(candidate):
                return self.send_file(candidate)
            relative = os.path.join("dashboard", rest)

        candidate = os.path.join(BASE_DIR, relative)
        if os.path.isdir(candidate):
            candidate = os.path.join(candidate, "index.html")
        if not os.path.isfile(candidate):
            return self.send_error_json(404, f"Not found: {path}")
        return self.send_file(candidate)

    def send_file(self, path: str):
        try:
            with open(path, "rb") as handle:
                body = handle.read()
        except OSError as exc:
            return self.send_error_json(500, f"Could not read {path}: {exc}")

        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype == "application/json":
            ctype += "; charset=utf-8"

        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        self.wfile.write(body)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} {APP_VERSION}")
    parser.add_argument("--config", default=os.path.join(BASE_DIR, "config.ini"))
    parser.add_argument("--bind", default="")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--once-check", action="store_true",
                        help="validate the configuration and exit without serving")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    cfg = load_config(args.config)
    bm.setup_logging(cfg, args.verbose)

    bind = args.bind or getattr(cfg, "api_bind", "0.0.0.0")
    port = args.port or getattr(cfg, "api_port", 8787)

    if args.once_check:
        print(f"config        : {cfg.path}")
        print(f"checks_dir    : {cfg.checks_dir}")
        print(f"server_list   : {cfg.server_list}")
        print(f"downtime_file : {cfg.downtime_file}")
        print(f"recipients    : {cfg.recipients_file}"
              f"{'' if os.path.isfile(cfg.recipients_file) else '  (not created yet - config.ini is in force)'}")
        print(f"session_dir   : {session_dir(cfg)}")
        try:
            targets = build_target_list(cfg)
            print(f"endpoints     : {targets['total_endpoints']}")
            for env in targets["environments"]:
                names = ", ".join(s["server_name"] for s in env["servers"])
                print(f"   {env['name']:<10} {names}")
        except Exception as exc:  # noqa: BLE001
            print(f"[!] Could not build the target list: {exc}")
            return 1
        windows = bm.load_downtime(cfg).get("windows", [])
        print(f"downtime      : {len(windows)} window(s)")
        for window in windows:
            state = "ACTIVE NOW" if bm.window_active(window, datetime.now()) else "idle"
            print(f"   [{state:>10}] {bm.describe_window(window)}"
                  f"  scope={window.get('scope')} {window.get('target','')}")
        return 0

    httpd = ThreadingHTTPServer((bind, port), Handler)
    httpd.cfg = cfg
    httpd.daemon_threads = True

    bm.log.info("%s %s listening on http://%s:%s", APP_NAME, APP_VERSION, bind, port)
    bm.log.info("   scheduler : http://<this-host>:%s/DT-SHDLR/", port)
    bm.log.info("   one-time  : http://<this-host>:%s/onetimerun/", port)
    bm.log.info("   dashboard : http://<this-host>:%s/", port)

    purge_sessions_async(cfg)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        bm.log.info("Stopped by operator.")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:
        # Someone piped us into `head` or `more`. Not an error worth a traceback.
        try:
            sys.stdout.close()
        except Exception:  # noqa: BLE001
            pass
        sys.exit(0)
    except KeyboardInterrupt:
        sys.exit(130)
