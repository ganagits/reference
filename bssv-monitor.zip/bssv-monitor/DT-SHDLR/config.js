/* ---------------------------------------------------------------------
   Where the backend service (bssv_api.py) is listening.

   Set this to the monitoring host and the port from [api] in config.ini,
   e.g.   window.BSSV_API = "http://jde-monitor01:8787";

   Leave it EMPTY to use the same host that served this page. That is what
   you want when you open the page from the service itself
   (http://<monitor-host>:8787/DT-SHDLR/) rather than from IIS.

   This is the only line to edit when the page is hosted in IIS.
   --------------------------------------------------------------------- */
window.BSSV_API = "";
